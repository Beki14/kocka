package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;


import android.health.connect.datatypes.units.Length;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView imageViewSlika;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = findViewById(R.id.textViewResult);
        imageViewSlika = findViewById(R.id.imageViewSlika);
    }

    public void clickButtonKocka(View view)
    {
        Random random;
        random = new Random();
        int BrojNaKocki = random.nextInt(6) + 1;

        String resultMessage = "Dobiveno na kocki: " + BrojNaKocki;
        textViewResult.setText(resultMessage);

        ImageView imageViewDice = findViewById(R.id.imageViewSlika);  // zamijenite s ID-om vašeg ImageView-a
        switch (BrojNaKocki) {
            case 1:
                imageViewDice.setImageResource(R.drawable.kocka1);
                break;
            case 2:
                imageViewDice.setImageResource(R.drawable.kocka2);
                break;
            case 3:
                imageViewDice.setImageResource(R.drawable.kocka3);
                break;
            case 4:
                imageViewDice.setImageResource(R.drawable.kocka4);
                break;
            case 5:
                imageViewDice.setImageResource(R.drawable.kocka5);
                break;
            case 6:
                imageViewDice.setImageResource(R.drawable.kocka6);
                break;
            default:
                break;
        }

    }
}